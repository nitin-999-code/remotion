import { Composition } from "remotion";
import { VideoWithCaptions } from "./VideoWithCaptions";

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="VideoWithCaptions"
        component={VideoWithCaptions as unknown as React.ComponentType<Record<string, unknown>>}
        durationInFrames={300}
        fps={30}
        width={1280}
        height={720}
        defaultProps={{
          videoUrl: "",
          captions: [],
          preset: {
            id: "bottom-centered",
            name: "Bottom Centered",
            style: {
              position: "bottom",
              alignment: "center",
              backgroundColor: "rgba(0, 0, 0, 0.8)",
              textColor: "white",
              fontSize: 24,
              padding: 16,
              borderRadius: 8,
              fontFamily: "Noto Sans, Noto Sans Devanagari, sans-serif",
            },
          },
        }}
      />
    </>
  );
};
